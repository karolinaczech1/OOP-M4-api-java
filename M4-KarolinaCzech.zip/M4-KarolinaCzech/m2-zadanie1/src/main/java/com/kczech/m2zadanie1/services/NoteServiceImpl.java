package com.kczech.m2zadanie1.services;

import com.kczech.m2zadanie1.api.mapper.NoteMapper;
import com.kczech.m2zadanie1.api.model.NoteDTO;
import com.kczech.m2zadanie1.domain.Library;
import com.kczech.m2zadanie1.domain.Note;
import com.kczech.m2zadanie1.repositories.NoteRepository;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class NoteServiceImpl implements NoteService{

    NoteRepository noteRepository;
    NoteMapper noteMapper;

    public NoteServiceImpl(NoteRepository noteRepository, NoteMapper noteMapper) {
        this.noteRepository = noteRepository;
        this.noteMapper = noteMapper;
    }

    @Override
    public List<NoteDTO> getAllNotes() {
        return noteRepository.findAll()
                .stream()
                .map(noteMapper::noteToNoteDTO)
                .collect(Collectors.toList());
    }

    @Override
    public NoteDTO getNoteById(Long id) {
        return noteMapper.noteToNoteDTO(noteRepository.findById(id).get());
    }

    @Override
    public List<NoteDTO> getNoteByCategory(String category) {
        return noteRepository.getByCategory(category)
                .stream()
                .map(noteMapper::noteToNoteDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<NoteDTO> getNoteByTitle(String title) {
        return noteRepository.getByTitle(title)
                .stream()
                .map(noteMapper::noteToNoteDTO)
                .collect(Collectors.toList());
    }

    @Override
    public NoteDTO createNewNote(NoteDTO noteDTO) {
        Note note = noteMapper.noteDTOToNote(noteDTO);
        note.setCreationDate(new Date());
        Note savedNote = noteRepository.save(note);
        return noteMapper.noteToNoteDTO(savedNote);
    }

    @Override
    public NoteDTO updateNote(Long id, NoteDTO noteDTO) {
        Note note = noteMapper.noteDTOToNote(noteDTO);
        note.setId(id);
        //note.setCreationDate(new Date());
        Note savedNote = noteRepository.save(note);
        return noteMapper.noteToNoteDTO(savedNote);
    }

    @Override
    public NoteDTO updateNotePatch(Long id, NoteDTO noteDTO) {
        Note note = noteMapper.noteDTOToNote(noteDTO);
        note.setId(id);
        Note theNote = noteRepository.findById(id).get();
        if(noteDTO.getTitle() == null) note.setTitle(theNote.getTitle());
        if(noteDTO.getCategory() == null) note.setCategory(theNote.getCategory());
        if(noteDTO.getCreationDate() == null) note.setCreationDate(theNote.getCreationDate());
        if(noteDTO.getNote() == null) note.setNote(theNote.getNote());
        Note savedNote = noteRepository.save(note);
        return noteMapper.noteToNoteDTO(savedNote);
    }


    @Override
    public void deleteNoteById(Long id) {
        noteRepository.deleteById(id);
    }
}
