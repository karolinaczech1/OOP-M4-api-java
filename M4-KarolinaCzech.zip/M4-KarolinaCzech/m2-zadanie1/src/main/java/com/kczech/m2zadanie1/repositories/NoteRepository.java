package com.kczech.m2zadanie1.repositories;

import com.kczech.m2zadanie1.domain.Note;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface NoteRepository extends JpaRepository<Note, Long> {
    List<Note> getByCategory(String category);
    List<Note> getByTitle(String title);
}
