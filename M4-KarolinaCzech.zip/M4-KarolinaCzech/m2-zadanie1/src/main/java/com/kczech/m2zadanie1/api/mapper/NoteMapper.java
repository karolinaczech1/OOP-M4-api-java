package com.kczech.m2zadanie1.api.mapper;

import com.kczech.m2zadanie1.api.model.LibraryDTO;
import com.kczech.m2zadanie1.api.model.NoteDTO;
import com.kczech.m2zadanie1.domain.Library;
import com.kczech.m2zadanie1.domain.Note;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface NoteMapper {

    NoteMapper INSTANCE = Mappers.getMapper(NoteMapper.class);

    NoteDTO noteToNoteDTO(Note note);

    Note noteDTOToNote(NoteDTO noteDTO);
}
