package com.kczech.m2zadanie1.services;

import com.kczech.m2zadanie1.api.mapper.LibraryMapper;
import com.kczech.m2zadanie1.api.model.LibraryDTO;
import com.kczech.m2zadanie1.domain.Library;
import com.kczech.m2zadanie1.repositories.LibraryRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class LibraryServiceImpl implements LibraryService{

    LibraryRepository libraryRepository;
    LibraryMapper libraryMapper;

    public LibraryServiceImpl(LibraryRepository libraryRepository, LibraryMapper libraryMapper) {
        this.libraryRepository = libraryRepository;
        this.libraryMapper = libraryMapper;
    }

    @Override
    public List<LibraryDTO> getAllBooks() {
        return libraryRepository.findAll()
                .stream()
                .map(libraryMapper::libraryToLibraryDTO)
                .collect(Collectors.toList());
    }

    @Override
    public LibraryDTO getBookById(Long id) {
        return libraryMapper.libraryToLibraryDTO(libraryRepository.findById(id).get());
    }

    @Override
    public List<LibraryDTO> getBookByStatus(String status) {
        return libraryRepository.getByStatus(status)
                .stream()
                .map(libraryMapper::libraryToLibraryDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<LibraryDTO> getBookByAuthor(String author) {
        return libraryRepository.getByAuthor(author)
                .stream()
                .map(libraryMapper::libraryToLibraryDTO)
                .collect(Collectors.toList());
    }


    @Override
    public LibraryDTO createNewBook(LibraryDTO libraryDTO) {
        Library book = libraryMapper.libraryDTOToLibrary(libraryDTO);
        Library savedBook = libraryRepository.save(book);
        return libraryMapper.libraryToLibraryDTO(savedBook);
    }

    @Override
    public LibraryDTO updateBook(Long id, LibraryDTO libraryDTO) {
        Library book = libraryMapper.libraryDTOToLibrary(libraryDTO);
        book.setId(id);
        Library savedBook = libraryRepository.save(book);
        return libraryMapper.libraryToLibraryDTO(savedBook);
    }

    @Override
    public LibraryDTO updateBookPatch(Long id, LibraryDTO libraryDTO) {
        Library book = libraryMapper.libraryDTOToLibrary(libraryDTO);
        book.setId(id);
        Library theBook = libraryRepository.findById(id).get();
        if(libraryDTO.getTitle() == null) book.setTitle(theBook.getTitle());
        if(libraryDTO.getAuthor() == null) book.setAuthor(theBook.getAuthor());
        if(libraryDTO.getStatus() == null) book.setStatus(theBook.getStatus());
        Library savedBook = libraryRepository.save(book);
        return libraryMapper.libraryToLibraryDTO(savedBook);
    }

    @Override
    public void deleteBookById(Long id) {
        libraryRepository.deleteById(id);
    }
}
