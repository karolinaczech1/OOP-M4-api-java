package com.kczech.m2zadanie1.Controllers;

import com.kczech.m2zadanie1.api.model.LibraryDTO;
import com.kczech.m2zadanie1.api.model.LibraryListDTO;
import com.kczech.m2zadanie1.services.LibraryService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "http://localhost:3000")
@Controller
@RequestMapping("/api/library/")
public class LibraryController {

    private final LibraryService libraryService;

    public LibraryController(LibraryService libraryService) {
        this.libraryService = libraryService;
    }

    //wyswietlanie (GET)

    @GetMapping()
    public ResponseEntity<LibraryListDTO> getAllBooks(){
        return new ResponseEntity<LibraryListDTO>(
                new LibraryListDTO(libraryService.getAllBooks()), HttpStatus.OK
        );
    }

    @GetMapping("{id}")
    public ResponseEntity<LibraryDTO> getBookById(@PathVariable Long id){
        return new ResponseEntity<LibraryDTO>(libraryService.getBookById(id), HttpStatus.OK);
    }

    @GetMapping("findByStatus/{status}")
    public ResponseEntity<LibraryListDTO> getBookByStatus(@PathVariable String status){
        return new ResponseEntity<LibraryListDTO>(
                new LibraryListDTO(libraryService.getBookByStatus(status)), HttpStatus.OK
        );
    }


    @GetMapping("findByAuthor/{author}")
    public ResponseEntity<LibraryListDTO> getBookByAuthor(@PathVariable String author){
        return new ResponseEntity<LibraryListDTO>(
                new LibraryListDTO(libraryService.getBookByAuthor(author)), HttpStatus.OK
        );
    }


    //tworzenie nowego obiektu (POST)

    @PostMapping
    public ResponseEntity<LibraryDTO> createNewBook(@RequestBody LibraryDTO libraryDTO){
        return new ResponseEntity<LibraryDTO>(libraryService.createNewBook(libraryDTO), HttpStatus.CREATED);

    }

    //edycja obiektu (PUT)

    @PutMapping("{id}")
    public ResponseEntity<LibraryDTO> updateBook(@PathVariable Long id,@RequestBody LibraryDTO libraryDTO){
        return new ResponseEntity<LibraryDTO>(libraryService.updateBook(id ,libraryDTO), HttpStatus.OK);

    }


    @PatchMapping("{id}")
    public ResponseEntity<LibraryDTO> updateBook2(@PathVariable Long id,@RequestBody LibraryDTO libraryDTO){
        return new ResponseEntity<LibraryDTO>(libraryService.updateBookPatch(id ,libraryDTO), HttpStatus.OK);

    }


    //usuwanie obiektu (DELETE)

    @DeleteMapping("{id}")
    public ResponseEntity<Void> deleteBookById(@PathVariable Long id){
        libraryService.deleteBookById(id);
        return new ResponseEntity<Void>(HttpStatus.OK);
    }


}
