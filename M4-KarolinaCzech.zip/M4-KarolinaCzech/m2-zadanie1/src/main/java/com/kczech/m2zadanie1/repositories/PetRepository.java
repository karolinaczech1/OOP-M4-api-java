package com.kczech.m2zadanie1.repositories;

import com.kczech.m2zadanie1.domain.Pet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import java.util.List;

@RepositoryRestResource(collectionResourceRel = "pet", path = "pet")
public interface PetRepository extends JpaRepository<Pet, Long> {

    List<Pet> findByName(@Param("name") String name);
    List<Pet> findByType(@Param("type") String type);
}
