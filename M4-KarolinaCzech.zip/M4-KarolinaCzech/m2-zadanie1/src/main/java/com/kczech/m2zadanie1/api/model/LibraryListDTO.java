package com.kczech.m2zadanie1.api.model;

import lombok.*;

import java.util.List;


@Data
@AllArgsConstructor
public class LibraryListDTO {

    private List<LibraryDTO> libraryList;
}
