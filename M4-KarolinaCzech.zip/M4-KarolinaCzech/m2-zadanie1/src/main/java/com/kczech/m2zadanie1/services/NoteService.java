package com.kczech.m2zadanie1.services;

import com.kczech.m2zadanie1.api.model.LibraryDTO;
import com.kczech.m2zadanie1.api.model.NoteDTO;

import java.util.List;

public interface NoteService {

    List<NoteDTO> getAllNotes();
    NoteDTO getNoteById(Long id);
    List<NoteDTO> getNoteByCategory(String category);
    List<NoteDTO> getNoteByTitle(String title);

    NoteDTO createNewNote(NoteDTO noteDTO);
    NoteDTO updateNote(Long id, NoteDTO noteDTO);
    NoteDTO updateNotePatch(Long id, NoteDTO noteDTO);
    void deleteNoteById(Long id);

}
