package com.kczech.m2zadanie1.api.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

@Data
public class NoteDTO {

    Long id;
    String title;
    String category;
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    Date creationDate;
    String note;
}
