package com.kczech.m2zadanie1.repositories;


import com.kczech.m2zadanie1.domain.Employee;
import com.kczech.m2zadanie1.domain.Pet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.config.RepositoryRestConfiguration;
import org.springframework.data.rest.webmvc.config.RepositoryRestConfigurer;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")
@RepositoryRestResource(collectionResourceRel = "employee", path = "employee")
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    List<Employee> findByName(@Param("name") String name);
    List<Employee> findByLastName(@Param("lastName") String lastName);
    List<Employee> findByPosition(@Param("position") String position);
    List<Employee> findByPhone(@Param("phone") Long phone);
}


