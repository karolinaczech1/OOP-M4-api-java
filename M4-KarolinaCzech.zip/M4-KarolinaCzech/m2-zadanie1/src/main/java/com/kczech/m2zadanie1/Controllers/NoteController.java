package com.kczech.m2zadanie1.Controllers;

import com.kczech.m2zadanie1.api.model.NoteDTO;
import com.kczech.m2zadanie1.services.NoteService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/note/")
public class NoteController {

    private final NoteService noteService;

    public NoteController(NoteService noteService) {
        this.noteService = noteService;
    }

    //wyświetlanie (GET)

    @GetMapping()
    @ResponseStatus(HttpStatus.OK)
    public List<NoteDTO> getAllNotes(){
        return noteService.getAllNotes();
    }

    @GetMapping("{id}")
    @ResponseStatus(HttpStatus.OK)
    public NoteDTO getNoteById(@PathVariable Long id){
        return noteService.getNoteById(id);
    }

    @GetMapping("findByCategory/{category}")
    @ResponseStatus(HttpStatus.OK)
    public List<NoteDTO> getNoteByCategory(@PathVariable String category){
        return noteService.getNoteByCategory(category);
    }

    @GetMapping("findByTitle/{title}")
    @ResponseStatus(HttpStatus.OK)
    public List<NoteDTO> getNoteByTitle(@PathVariable String title){
        return noteService.getNoteByTitle(title);
    }


    //dodawanie nowego obiektu (POST)

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public NoteDTO createNewNote(@RequestBody NoteDTO noteDTO){
        return noteService.createNewNote(noteDTO);
    }


    //edycja obiektu (PUT)

    @PutMapping("{id}")
    @ResponseStatus(HttpStatus.OK)
    public NoteDTO updateNote(@PathVariable Long id,@RequestBody NoteDTO noteDTO){
        return noteService.updateNote(id, noteDTO);
    }

    @PatchMapping("{id}")
    @ResponseStatus(HttpStatus.OK)
    public NoteDTO updateNote2(@PathVariable Long id,@RequestBody NoteDTO noteDTO){
        return noteService.updateNotePatch(id, noteDTO);
    }



    //usuwanie obiektu (DELETE)

    @DeleteMapping("{id}")
    @ResponseStatus(HttpStatus.OK)
    public Void deleteNoteById(@PathVariable Long id){
        noteService.deleteNoteById(id);
        return null;
    }


}
