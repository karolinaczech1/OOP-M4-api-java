package com.kczech.m2zadanie1.api.model;

import lombok.Data;

@Data
public class LibraryDTO {

    Long id;
    String title;
    String author;
    String status;
}
