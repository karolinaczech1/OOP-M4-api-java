package com.kczech.m2zadanie1.services;

import com.kczech.m2zadanie1.api.model.LibraryDTO;
import org.springframework.stereotype.Service;

import java.util.List;


public interface LibraryService {

    List<LibraryDTO> getAllBooks();
    LibraryDTO getBookById(Long id);
    List<LibraryDTO> getBookByStatus(String status);
    List<LibraryDTO> getBookByAuthor(String author);

    LibraryDTO createNewBook(LibraryDTO libraryDTO);
    LibraryDTO updateBook(Long id, LibraryDTO libraryDTO);
    LibraryDTO updateBookPatch(Long id, LibraryDTO libraryDTO);
    void deleteBookById(Long id);

}
