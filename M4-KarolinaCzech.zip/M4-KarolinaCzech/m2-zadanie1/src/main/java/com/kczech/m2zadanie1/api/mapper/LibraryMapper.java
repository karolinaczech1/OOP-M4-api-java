package com.kczech.m2zadanie1.api.mapper;

import com.kczech.m2zadanie1.api.model.LibraryDTO;
import com.kczech.m2zadanie1.domain.Library;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface LibraryMapper {

    LibraryMapper INSTANCE = Mappers.getMapper(LibraryMapper.class);

    LibraryDTO libraryToLibraryDTO(Library book);

    Library libraryDTOToLibrary(LibraryDTO libraryDTO);

}
