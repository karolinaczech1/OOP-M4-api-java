package com.kczech.m2zadanie1.bootstrap;

import com.kczech.m2zadanie1.domain.Employee;
import com.kczech.m2zadanie1.domain.Library;
import com.kczech.m2zadanie1.domain.Note;
import com.kczech.m2zadanie1.domain.Pet;
import com.kczech.m2zadanie1.repositories.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Calendar;
import java.util.Date;

@Component
public class DBDataLoader implements CommandLineRunner {

    LibraryRepository libraryRepository;
    NoteRepository noteRepository;
    PetRepository petRepository;
    EmployeeRepository employeeRepository;

    public DBDataLoader(LibraryRepository libraryRepository, NoteRepository noteRepository, PetRepository petRepository, EmployeeRepository employeeRepository) {
        this.libraryRepository = libraryRepository;
        this.noteRepository = noteRepository;
        this.petRepository = petRepository;
        this.employeeRepository = employeeRepository;
    }

    @Override
    public void run(String... args) throws Exception {

        //Library

        Library book1 = new Library();
        book1.setTitle("Harry Potter");
        book1.setAuthor("J.K. Rowling");
        book1.setStatus("available");

        Library book2 = new Library();
        book2.setTitle("The Shining");
        book2.setAuthor("Stephen King");
        book2.setStatus("available");

        Library book3 = new Library();
        book3.setTitle("This Is Going to Hurt");
        book3.setAuthor("Adam Kay");
        book3.setStatus("available");

        Library book4 = new Library();
        book4.setTitle("The Power of Habit");
        book4.setAuthor("Charles Duhigg");
        book4.setStatus("available");

        libraryRepository.save(book1);
        libraryRepository.save(book2);
        libraryRepository.save(book3);
        libraryRepository.save(book4);

        //Note

        Calendar cal = Calendar.getInstance();
        cal.set(2020, 11, 14, 10, 30, 40);
        Date date = cal.getTime();


        Note note1 = new Note();
        note1.setTitle("Notatka 1");
        note1.setCategory("category 1");
        note1.setCreationDate(date);
        note1.setNote("To jest pierwsza notatka.");

        Note note2 = new Note();
        note2.setTitle("Notatka 2");
        note2.setCategory("category 1");
        note2.setCreationDate(date);
        note2.setNote("To jest druga notatka.");

        noteRepository.save(note1);
        noteRepository.save(note2);


        //Pet

        Pet cat = new Pet();
        cat.setType("kot");
        cat.setName("Cat");

        Pet dog = new Pet();
        dog.setType("pies");
        dog.setName("Dog");

        petRepository.save(cat);
        petRepository.save(dog);


        //Employee

       Employee e1 = new Employee();
       e1.setName("Jan");
       e1.setLastName("Kowalski");
       e1.setPosition("Java Developer");
       e1.setEmail("jan@kowalski.pl");
       e1.setPhone(508987378l);

        Employee e2 = new Employee();
        e2.setName("Anna");
        e2.setLastName("Nowak");
        e2.setPosition("CEO");
        e2.setEmail("anna-nowak@gmail.com");
        e2.setPhone(503765267l);

        employeeRepository.save(e1);
        employeeRepository.save(e2);

        System.out.println("Data loaded to DB.");

    }
}
