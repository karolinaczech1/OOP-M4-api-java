package com.kczech.m2zadanie1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@SpringBootApplication
public class M2Zadanie1Application {

    public static void main(String[] args) throws Throwable {
        SpringApplication.run(M2Zadanie1Application.class, args);
    }

}
