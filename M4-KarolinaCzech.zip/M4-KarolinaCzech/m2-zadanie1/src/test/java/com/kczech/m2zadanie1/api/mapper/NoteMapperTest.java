package com.kczech.m2zadanie1.api.mapper;

import com.kczech.m2zadanie1.api.model.LibraryDTO;
import com.kczech.m2zadanie1.api.model.NoteDTO;
import com.kczech.m2zadanie1.domain.Library;
import com.kczech.m2zadanie1.domain.Note;
import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class NoteMapperTest {

    NoteMapper noteMapper = NoteMapper.INSTANCE;

    @Test
    void noteToNoteDTO() {

        Calendar cal = Calendar.getInstance();
        cal.set(2020, 11, 14);
        cal.set(Calendar.HOUR_OF_DAY,17);
        cal.set(Calendar.MINUTE,30);
        Date date = cal.getTime();

        Note note = new Note();
        note.setId(1L);
        note.setTitle("note");
        note.setCategory("category");
        note.setCreationDate(date);
        note.setNote("this is note for tests");

        NoteDTO noteDTO = noteMapper.noteToNoteDTO(note);

        assertEquals(Long.valueOf(1L), noteDTO.getId());
        assertEquals("note", noteDTO.getTitle());
        assertEquals("category", noteDTO.getCategory());
        assertEquals(date, noteDTO.getCreationDate());
        assertEquals("this is note for tests", noteDTO.getNote());


    }
}