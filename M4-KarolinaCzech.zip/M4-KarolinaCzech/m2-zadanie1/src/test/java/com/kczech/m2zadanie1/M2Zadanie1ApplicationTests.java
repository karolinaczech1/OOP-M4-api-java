package com.kczech.m2zadanie1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class M2Zadanie1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
