package com.kczech.m2zadanie1.api.mapper;

import com.kczech.m2zadanie1.api.model.LibraryDTO;
import com.kczech.m2zadanie1.domain.Library;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LibraryMapperImplTest {

    LibraryMapper libraryMapper = LibraryMapper.INSTANCE;

    @Test
    void libraryToLibraryDTO() {
        //given
        Library book = new Library();
        book.setId(1L);
        book.setTitle("Book");
        book.setAuthor("Author");
        book.setStatus("available");

        //when
        LibraryDTO libraryDTO = libraryMapper.libraryToLibraryDTO(book);

        //then
        assertEquals(Long.valueOf(1), book.getId());
        assertEquals("Book", book.getTitle());
        assertEquals("Author", book.getAuthor());
        assertEquals("available", book.getStatus());
    }
}